﻿<?php
$file = basename(__FILE__);
if(eregi($file,$_SERVER['REQUEST_URI'])) {
    die("Sorry but you cannot access this file directly for security reasons.");
}
?>

<div id="footer">
			<div id="footer-content">
			<center>
			Copyright &copy; 2010 - 2011, @ZoltanElDiablo <br />
			<p style="text-align: center;">Voce possui atualmente <span style="color: lime; font-weight: bold;"><?php echo $shellsOnline; ?></span> shells online. O horario do servidor eh <font color="#666666"><strong><?php $date = date("h:i:s A", time()); echo $date; ?></strong></font>.</p>
			</center>
			</div>
		</div>
	</div>
