<table width="100%" border="0" cellspacing="0" cellpadding="5" class="main">
  <tr> 
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr> 
    <td width="160" valign="top"><p>&nbsp;</p>
      <p>&nbsp; </p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p></td>
    <td width="732" valign="top">
      <h4>Your registration is now complete!</h4>
      <p><font size="2" face="Arial, Helvetica, sans-serif">Your request to join the community has been submitted. An administrator will shortly either approve or deny of this request. If you are a paid customer, please contact the webmaster and notify him. This is a moderated registration community, meaning only approved members will be given access. If you are ready to login, please click <a href="login.php">here</a>!</font></p>
      <p>&nbsp;</p>
	   
      <p align="right">&nbsp; </p></td>
    <td width="196" valign="top">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3">&nbsp;</td>
  </tr>
</table>
